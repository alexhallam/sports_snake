from setuptools import setup

setup(name='sports_snake',
      version='0.1',
      description='Make sports pulling easy',
      url='https://github.com/alexhallam/sportsnake.git',
      author='Alex Hallam',
      author_email='alexhallam@gmail.com',
      license='MIT',
      packages=['sports_snake'],
      zip_safe=False)

